## Sobek

Is a fork of [goja](https://github.com/dop251/goja) named after the [ancient Egyptian god](https://en.wikipedia.org/wiki/Sobek) of the same name

The fork is currently just aliasing types in order to facilitate the moving of the current k6 codebase and extension to it with less friction.

The plan and discussion on the transition can be find in [this issue](https://github.com/grafana/k6/issues/3773).
