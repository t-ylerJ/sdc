// Package k6test provides mock implementations of k6 elements for testing purposes.
package k6test
