// Package common provides the main logic of the browser module.
// This package will be split into multiple packages in the future.
package common
