// Package k6ext acts as an encapsulation layer between the k6 core and xk6-browser.
package k6ext
