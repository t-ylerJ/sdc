# Old TypeScript version

This is used to ensure that our type definitions don't accidentally use newer features that break in older versions of TypeScript.
