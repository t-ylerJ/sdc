This Go implementation of xxHash is from https://github.com/cespare/xxhash.
