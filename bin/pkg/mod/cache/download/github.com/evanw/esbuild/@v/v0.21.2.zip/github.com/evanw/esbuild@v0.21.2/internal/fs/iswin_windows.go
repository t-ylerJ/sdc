//go:build windows
// +build windows

package fs

func CheckIfWindows() bool {
	return true
}
