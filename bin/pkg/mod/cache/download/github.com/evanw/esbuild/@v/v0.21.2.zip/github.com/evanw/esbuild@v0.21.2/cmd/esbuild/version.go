package main

const esbuildVersion = "0.21.2"
