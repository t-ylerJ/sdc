# compat-table

This code generates esbuild's internal browser compatibility tables from 3rd-party browser compatibility data. Run this code with `make compat-table` in the top-level repository directory. Update the data sources behind these tables using `make update-compat-table`.
