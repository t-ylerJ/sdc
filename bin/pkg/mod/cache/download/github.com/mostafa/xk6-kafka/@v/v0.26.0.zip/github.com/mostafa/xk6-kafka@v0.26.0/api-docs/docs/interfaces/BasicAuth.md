# Interface: BasicAuth

## Table of contents

### Properties

- [password](BasicAuth.md#password)
- [username](BasicAuth.md#username)

## Properties

### password

• **password**: `string`

#### Defined in

[index.d.ts:154](https://github.com/mostafa/xk6-kafka/blob/main/api-docs/index.d.ts#L154)

---

### username

• **username**: `string`

#### Defined in

[index.d.ts:153](https://github.com/mostafa/xk6-kafka/blob/main/api-docs/index.d.ts#L153)
