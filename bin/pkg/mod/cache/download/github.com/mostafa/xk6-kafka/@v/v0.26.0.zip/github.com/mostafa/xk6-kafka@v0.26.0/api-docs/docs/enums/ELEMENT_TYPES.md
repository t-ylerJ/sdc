# Enumeration: ELEMENT_TYPES

## Table of contents

### Enumeration Members

- [KEY](ELEMENT_TYPES.md#key)
- [VALUE](ELEMENT_TYPES.md#value)

## Enumeration Members

### KEY

• **KEY**

#### Defined in

[index.d.ts:42](https://github.com/mostafa/xk6-kafka/blob/main/api-docs/index.d.ts#L42)

---

### VALUE

• **VALUE**

#### Defined in

[index.d.ts:43](https://github.com/mostafa/xk6-kafka/blob/main/api-docs/index.d.ts#L43)
