# Enumeration: START_OFFSETS

## Table of contents

### Enumeration Members

- [START_OFFSETS_FIRST_OFFSET](START_OFFSETS.md#start_offsets_first_offset)
- [START_OFFSETS_LAST_OFFSET](START_OFFSETS.md#start_offsets_last_offset)

## Enumeration Members

### START_OFFSETS_FIRST_OFFSET

• **START_OFFSETS_FIRST_OFFSET**

#### Defined in

[index.d.ts:55](https://github.com/mostafa/xk6-kafka/blob/main/api-docs/index.d.ts#L55)

---

### START_OFFSETS_LAST_OFFSET

• **START_OFFSETS_LAST_OFFSET**

#### Defined in

[index.d.ts:54](https://github.com/mostafa/xk6-kafka/blob/main/api-docs/index.d.ts#L54)
