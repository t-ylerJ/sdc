# Interface: ProduceConfig

## Table of contents

### Properties

- [messages](ProduceConfig.md#messages)

## Properties

### messages

• **messages**: [`Message`](Message.md)[]

#### Defined in

[index.d.ts:166](https://github.com/mostafa/xk6-kafka/blob/main/api-docs/index.d.ts#L166)
