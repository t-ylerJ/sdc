# Interface: ConfigEntry

## Table of contents

### Properties

- [configName](ConfigEntry.md#configname)
- [configValue](ConfigEntry.md#configvalue)

## Properties

### configName

• **configName**: `string`

#### Defined in

[index.d.ts:223](https://github.com/mostafa/xk6-kafka/blob/main/api-docs/index.d.ts#L223)

---

### configValue

• **configValue**: `string`

#### Defined in

[index.d.ts:224](https://github.com/mostafa/xk6-kafka/blob/main/api-docs/index.d.ts#L224)
