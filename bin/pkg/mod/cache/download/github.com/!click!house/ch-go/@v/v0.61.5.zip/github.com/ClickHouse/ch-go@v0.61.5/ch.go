// Package ch implements ClickHouse client.
package ch
