/*
Package http provides the HTTP transport client and request/response types
needed to round trip API operation calls with an service.
*/
package http
