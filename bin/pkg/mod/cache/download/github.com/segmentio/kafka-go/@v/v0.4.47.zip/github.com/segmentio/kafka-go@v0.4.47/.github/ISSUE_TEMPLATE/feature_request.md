---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**Describe the solution you would like**

> A clear and concise description of what you want to happen.

**Supporting documentation**

> Please provides links to relevant Kafka protocol docs and/or KIPs.
