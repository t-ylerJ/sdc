package consts

// JS constants
const (
	DefaultFn       = "default"
	Options         = "options"
	SetupFn         = "setup"
	TeardownFn      = "teardown"
	HandleSummaryFn = "handleSummary"
)
