// Package strvals provides parsing utilities for strval lines, which follow
// the format: name=value,topname.subname=value.
package strvals
