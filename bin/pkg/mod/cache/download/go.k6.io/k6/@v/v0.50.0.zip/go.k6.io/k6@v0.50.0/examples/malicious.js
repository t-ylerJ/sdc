export default function() {
	while (true) {
		// do nothing, forever!!
	}
}
