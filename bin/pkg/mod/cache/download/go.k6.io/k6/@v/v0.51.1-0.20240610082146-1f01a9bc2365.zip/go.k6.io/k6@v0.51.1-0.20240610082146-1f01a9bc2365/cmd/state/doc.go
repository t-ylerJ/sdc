// Package state contains the types and functionality used for keeping track of
// cmd-related values that are used globally throughout k6. It also exposes some
// related test types and helpers.
package state
